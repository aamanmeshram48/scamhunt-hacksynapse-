# ScamHunt 2.0 — Mobile Threat Defense Suite

> **Built from Google Stitch Project ID:** `18431355943067046596`  
> **Source Platform:** [Google Stitch (stitch.withgoogle.com)](https://stitch.withgoogle.com/projects/18431355943067046596)  
> **Application Type:** Progressive Web Application (PWA) / Responsive Mobile Security Suite

---

## 🛡️ Overview

**ScamHunt 2.0** is an AI-assisted, explainable cybersecurity and digital fraud defense application. It empowers citizens and organizations to **detect, assess, contain, and legally preserve evidence** against digital scams, phishing messages, extortion, identity impersonation, and fraudulent UPI payment requests.

---

## 📱 The 8 Stitched Screens

1. **Splash & Welcome** (`5902862ab6664ca388b09e07fa253b42`)
   - High-impact visual branding with glowing radar sweep.
   - Core value propositions: Multi-Vector Scanner, Section 65B Legal Evidence Stamping.
   - Onboarding flow with *Get Started* and *Sign In* actions.

2. **Authentication** (`26dbe8913c2f4e84968a9128f3f1d9bb`)
   - Secure PIN / Mobile credential authentication.
   - One-tap Biometric (Fingerprint / Face ID) simulation.
   - Emergency Attack Bypass: Jump directly to Incident Response during active fraud without login delay.

3. **Home Dashboard** (`880d1969b2a443819bc53f6ccd5e9ff0`)
   - Live protection status banner (*Device Protection: Active & Vigilant*).
   - Primary Hero Quick Scan launcher card.
   - Threat counters: Threats Blocked, Active Incidents, Safe Verified.
   - Quick Inspection tool cards (SMS, URLs, Incident Response, Evidence Creator).
   - Recent cases timeline list with risk-coded indicator dots.

4. **Scan Hub** (`1be329c70cf5434c8bbff34aedd24123`)
   - Multi-vector scanner with format selector tabs (*Message*, *URL*, *UPI/QR*, *File/APK*).
   - 5 Realistic Quick-Preset Chips (*Electricity Power Cut*, *SBI KYC Suspension*, *Telegram Job 5000/day*, *KBC 25 Lakh Lottery*, *Legitimate Flight Ticket*).
   - Real-time heuristic scanning progress beam.
   - 100% On-Device privacy guarantee note.

5. **Threat Analysis Detail** (`b1f07ea831964590b498aa483138a86e`)
   - Animated circular SVG 0–100 Risk Gauge with color-coded safety level.
   - Classified threat title (e.g. *Phishing / Banking Scam*).
   - Original message display box.
   - Explainable AI detected indicators breakdown with icons and plain-language reasons.
   - Immediate containment recommendation banner.
   - Escalation buttons to *Incident Response* and *Evidence Creator*.

6. **Incident Response** (`9ca374f6a18848aeb59a99a5d7fad008`)
   - Active Incident Case ID badge (`SC-2026-XXXXXX`).
   - Emergency **National Cyber Crime Helpline 1930** call card with one-tap dialer (`tel:1930`).
   - Interactive 5-step containment checklist:
     1. Stop All Communication
     2. Freeze Compromised Banking / UPI
     3. Preserve Raw Digital Evidence
     4. Record Citizen Incident Number
     5. Lodge Official Complaint on `cybercrime.gov.in`
   - Real-time timestamped case event log.

7. **Evidence Creator** (`62a7e7502cd2428c91be96d4e06239ac`)
   - Cryptographic SHA-256 integrity stamping compliant with Section 65B of the Indian Evidence Act.
   - Quick-add evidence carousel (Screenshots, UPI Receipts, Call Logs, Bank PDFs).
   - Chain of custody items list with verified hash badges.
   - Four Export formats:
     - 📥 **Download Official Police Dossier (.TXT)**
     - 💾 **Export JSON Evidence Package (.JSON)**
     - 🖨️ **Print / Save as PDF**
     - 📋 **Copy 1930 Helpline Phone Script**

8. **Profile & Settings** (`6fc70747d26f423094f2cd7efadfa6f1`)
   - User security card with Pro Defended status badge.
   - Emergency SOS directory (National Cyber Helpline 1930, Bank Fraud Hotlines).
   - Heuristic Engine sensitivity slider (Standard / Strict / Paranoid).
   - Offline-First zero cloud upload toggle.
   - Local scan data management & reset controls.

---

## 🚀 How to Run

### Method 1: Direct in Browser
Simply double-click `index.html` or open it in any modern browser:
```
c:\Users\hp\Desktop\scamhunt2.0\index.html
```

### Method 2: Zero-Dependency PowerShell Server
In PowerShell from this folder:
```powershell
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```
This starts a local server on `http://localhost:8080` and opens your default browser automatically.

### Method 3: Python Server
If Python is installed:
```bash
python serve.py
```

---

## 🔒 Security & Privacy Architecture
- **100% Client-Side Heuristics:** No raw messages or files are transmitted to external servers or third-party AI APIs.
- **Web Crypto API:** Uses native in-browser cryptographic primitives (`crypto.subtle.digest`) for real SHA-256 tamper-proof verification.
- **Local Persistence:** Cases and checklists are safely stored in browser `localStorage`.
